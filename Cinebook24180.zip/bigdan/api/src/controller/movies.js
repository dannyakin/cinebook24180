const cloudinary = require("cloudinary").v2;
const Movie = require("../models/movie");
const multer = require("multer");
exports.createMovie = async (req, res) => {
  try {
    // Upload image to Cloudinary
    // Create new movie with Cloudinary image URL
    const newMovie = new Movie({
      title: req.body.title,
      description: req.body.description,
      releaseDate: req.body.releaseDate,
      age: req.body.age,
      seat: req.body.seat,
      time: req.body.showTime,
      genres: req.body.genres,
      locations: req.body.locations,
      image: req.body.image // Store Cloudinary image URL in database
    });

    const savedMovie = await newMovie.save();
    res.status(201).json(savedMovie);
  } catch (error) {
    console.error("Error creating movie:", error);
    res.status(500).json({ error: "Server error" });
  }
};

// Controller function to edit an existing movie
exports.editMovie = async (req, res) => {
  try {
    let updatedData = { ...req.body };

    // Check if a new image is provided
    if (req.file) {
      // Upload new image to Cloudinary
      const result = await cloudinary.uploader.upload(req.file.path);
      updatedData.image = result.secure_url; // Update image URL in updatedData
    }

    // Find and update the movie by ID
    const updatedMovie = await Movie.findByIdAndUpdate(
      req.params.id,
      updatedData,
      { new: true }
    );
    res.status(200).json(updatedMovie);
  } catch (error) {
    console.error("Error editing movie:", error);
    res.status(500).json({ error: "Server error" });
  }
};

// Controller function to get all movies
exports.getAllMovies = async (req, res) => {
  try {
    const movies = await Movie.find();
    res.status(200).json(movies);
  } catch (error) {
    console.error("Error getting all movies:", error);
    res.status(500).json({ error: "Server error" });
  }
};

// Controller function to get a single movie by ID
exports.getMovieById = async (req, res) => {
  try {
    const movie = await Movie.findById(req.params.id);
    res.status(200).json(movie);
  } catch (error) {
    console.error("Error getting movie by ID:", error);
    res.status(500).json({ error: "Server error" });
  }
};

// Controller function to delete a movie by ID
exports.deleteMovie = async (req, res) => {
  try {
    await Movie.findByIdAndDelete(req.params.id);
    res.status(204).end();
  } catch (error) {
    console.error("Error deleting movie:", error);
    res.status(500).json({ error: "Server error" });
  }
};

// Add Multer middleware to the routes that need it