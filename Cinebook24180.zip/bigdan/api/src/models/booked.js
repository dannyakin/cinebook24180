const mongoose = require("mongoose");

// Define the schema for the booking information
const bookingSchema = new mongoose.Schema({
  amount: {
    type: Number,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  movieId: {
    type: String,
    required: true,
  },
  seat: {
    type: [String],
    required: true,
  },
  time: {
    type: String,
    required: true,
  },
});

// Create the Mongoose model based on the schema
const Booking = mongoose.model("Booking", bookingSchema);

module.exports = Booking;
