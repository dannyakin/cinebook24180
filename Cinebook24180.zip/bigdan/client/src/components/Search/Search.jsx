import React from "react";

const Search = () => {
  return (
    <div className="flex border items-center justify-center rounded-full px-4 py-2 gap-2 bg-gray-200">
      <div className="">
        <svg
          width="17"
          height="17"
          viewBox="0 0 17 17"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M7.79167 13.4583C10.9213 13.4583 13.4583 10.9213 13.4583 7.79167C13.4583 4.66205 10.9213 2.125 7.79167 2.125C4.66205 2.125 2.125 4.66205 2.125 7.79167C2.125 10.9213 4.66205 13.4583 7.79167 13.4583Z"
            stroke="#5F5F5F"
            stroke-width="1.41667"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
          <path
            d="M14.8751 14.875L11.7938 11.7937"
            stroke="#5F5F5F"
            stroke-width="1.41667"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        </svg>
      </div>
      <input
        type="text"
        placeholder="What is on your mind"
        className="border-none outline-none w-56 focus:outline-none hidden md:block bg-transparent text-sm"
      />
    </div>
  );
};

export default Search;
