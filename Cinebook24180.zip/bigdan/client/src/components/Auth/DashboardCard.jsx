import React from "react";
import { CiUser } from "react-icons/ci";
import { FaTicketSimple } from "react-icons/fa6";
import { MdAirlineSeatLegroomExtra } from "react-icons/md";
import { MdLocalMovies } from "react-icons/md";

const DashboardCard = ({ count, title, details, icon, color, bgcolor }) => {
  return (
    <div className={` rounded-xl ${bgcolor} p-3 px-5 relative`}>
      <div
        className={`${color} w-12 h-10 rounded-full flex items-center justify-center text-white text-xl absolute right-2`}
      >
        {icon === "user" ? (
          <CiUser />
        ) : icon === "movie" ? (
          <MdLocalMovies />
        ) : icon === "ticket" ? (
          <FaTicketSimple />
        ) : (
          <MdAirlineSeatLegroomExtra />
        )}
      </div>

      <div className="mt-3 text-3xl font-extrabold mb-1">{count}</div>
      <div className="text-xs mb-1">{title}</div>
      <div className="text-xs ">{details}</div>
    </div>
  );
};

export default DashboardCard;
