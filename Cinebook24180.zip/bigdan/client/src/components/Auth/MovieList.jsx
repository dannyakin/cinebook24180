import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Table, Spin, Image, Button, Popconfirm } from "antd"; // Import Button and Popconfirm components from Ant Design
import {
  fetchMoviesThunk,
  deleteMovieThunk,
} from "../../function/Redux/movie/movieAction";

const MovieList = () => {
  const { movies, loading } = useSelector((state) => state.movies);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchMoviesThunk());
  }, []);

  const handleDelete = (movieId) => {
    // Dispatch action to delete movie
    dispatch(deleteMovieThunk(movieId));
  };

  const columns = [
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
    },
    {
      title: "Description",
      dataIndex: "description",
      key: "description",
    },
    {
      title: "Release Date",
      dataIndex: "releaseDate",
      key: "releaseDate",
    },
    {
      title: "Age",
      dataIndex: "age",
      key: "age",
    },
    {
      title: "Image",
      dataIndex: "image",
      key: "image",
      render: (image) => <Image src={image} width={100} />,
    },
    {
      title: "Action",
      key: "action",
      render: (text, record) => (
        <Popconfirm
          title="Are you sure you want to delete this movie?"
          onConfirm={() => handleDelete(record._id)} // Call handleDelete with movie ID when confirming deletion
          okText="Yes"
          cancelText="No"
        >
          <Button type="danger" size="small">
            Delete
          </Button>
        </Popconfirm>
      ),
    },
  ];

  return (
    <div className="mt-4">
      {loading ? (
        <div className="w-full h-full flex items-center justify-center">
        <Spin size="large" /> </div>
      ) : (
        <Table dataSource={movies} columns={columns} />
      )}
    </div>
  );
};

export default MovieList;
