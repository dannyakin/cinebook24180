import React, { useState, useEffect } from "react";
import { IoTimeSharp } from "react-icons/io5";

const data = [
  {
    image: "/assets/images/mp1.png",
    title: "The Beekeeper",
    details:
      "Willy Wonka – chock-full of ideas and determined to change the world one delectable bite at a time – is proof that the bestthings in life begin with a dream, and if you’re lucky enough to meet Willy Wonka, anything is possible",
    genre: ["Action", "Thriller"],
    duration: "1hr 45mins",
    rating: 4.5,
    age: "pg",
  },
  {
    image: "/assets/images/mp2.png",
    title: "The Beekeeper",
    details:
      "Willy Wonka – chock-full of ideas and determined to change the world one delectable bite at a time – is proof that the bestthings in life begin with a dream, and if you’re lucky enough to meet Willy Wonka, anything is possible",

    genre: ["Action", "Thriller"],
    duration: "1hr 45mins",
    rating: 4.5,
    age: "18",
  },
  {
    image: "/assets/images/mp3.png",
    title: "The Beekeeper",
    details:
      "Willy Wonka – chock-full of ideas and determined to change the world one delectable bite at a time – is proof that the bestthings in life begin with a dream, and if you’re lucky enough to meet Willy Wonka, anything is possible",

    genre: ["Action", "Thriller"],
    duration: "1hr 45mins",
    rating: 4.5,
    age: "16",
  },
  {
    image: "/assets/images/mp4.png",
    details:
      "Willy Wonka – chock-full of ideas and determined to change the world one delectable bite at a time – is proof that the bestthings in life begin with a dream, and if you’re lucky enough to meet Willy Wonka, anything is possible",

    title: "The Beekeeper",
    genre: ["Action", "Thriller"],
    duration: "1hr 45mins",
    rating: 4.5,
    age: "15A",
  },
];

const Slide = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [startX, setStartX] = useState(0);
  const [isDragging, setIsDragging] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) =>
        prevIndex === data.length - 1 ? 0 : prevIndex + 1
      );
    }, 5000); // Change slide every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const handleTouchStart = (e) => {
    setIsDragging(true);
    setStartX(e.touches[0].clientX);
  };

  const handleTouchMove = (e) => {
    if (!isDragging) return;
    const currentX = e.touches[0].clientX;
    const difference = startX - currentX;
    if (Math.abs(difference) > 30) {
      // Adjust sensitivity as needed
      if (difference > 0) {
        // Swipe left
        setCurrentIndex((prevIndex) =>
          prevIndex === data.length - 1 ? 0 : prevIndex + 1
        );
      } else {
        // Swipe right
        setCurrentIndex((prevIndex) =>
          prevIndex === 0 ? data.length - 1 : prevIndex - 1
        );
      }
      setIsDragging(false);
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  return (
    <div
      className="relative"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <div className="flex items-center overflow-hidden">
        {data.map((item, index) => (
          <div
            key={index}
            className={`bg-cover bg-no-repeat min-w-[100vw] h-[70vh]  ${
              currentIndex === index ? "" : "hidden"
            }`}
            style={{
              backgroundImage: `url(${item.image})`,
              transition: "opacity 3s ease", // Add transition property
              opacity: currentIndex === index ? 1 : 0, // Fade in/out based on currentIndex
            }}
          >
            <div
              className="flex items-center bg-center bg-cover bg-no-repeat w-full h-full"
              style={{
                backgroundImage: `url('/assets/images/bg.png')`,
              }}
            >
              <div className="container mx-auto">
                {/* You can add additional content inside the slide item */}
                <div className="flex gap-2 text-white mb-2">
                  {item.genre.map((gn, i) => (
                    <div className="text-[12px] " key={i}>
                      {gn}
                    </div>
                  ))}
                </div>

                {item.age === "pg" && (
                  <div className="flex items-center gap-2">
                    <div className="">
                      <svg
                        width="30"
                        height="30"
                        viewBox="0 0 30 30"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <circle
                          cx="15"
                          cy="15"
                          r="14"
                          fill="#001F8C"
                          stroke="white"
                          stroke-width="2"
                        />
                        <path
                          d="M7.99417 19V10.2727H11.2669C11.9374 10.2727 12.4999 10.3977 12.9544 10.6477C13.4118 10.8977 13.757 11.2415 13.9899 11.679C14.2257 12.1136 14.3436 12.608 14.3436 13.1619C14.3436 13.7216 14.2257 14.2187 13.9899 14.6534C13.7541 15.0881 13.4061 15.4304 12.9459 15.6804C12.4856 15.9276 11.9189 16.0511 11.2456 16.0511H9.07656V14.7514H11.0325C11.4246 14.7514 11.7456 14.6832 11.9956 14.5469C12.2456 14.4105 12.4303 14.223 12.5496 13.9844C12.6717 13.7457 12.7328 13.4716 12.7328 13.1619C12.7328 12.8523 12.6717 12.5795 12.5496 12.3438C12.4303 12.108 12.2442 11.9247 11.9913 11.794C11.7413 11.6605 11.4189 11.5938 11.024 11.5938H9.57514V19H7.99417ZM21.5154 13.0597C21.4444 12.8295 21.3464 12.6236 21.2214 12.4418C21.0992 12.2571 20.9515 12.0994 20.7782 11.9688C20.6077 11.8381 20.4117 11.7401 20.1901 11.6747C19.9685 11.6065 19.7271 11.5724 19.4657 11.5724C18.997 11.5724 18.5793 11.6903 18.2129 11.9261C17.8464 12.1619 17.558 12.5085 17.3478 12.9659C17.1404 13.4205 17.0367 13.9744 17.0367 14.6278C17.0367 15.2869 17.1404 15.8452 17.3478 16.3026C17.5552 16.7599 17.8435 17.108 18.2129 17.3466C18.5822 17.5824 19.0112 17.7003 19.4998 17.7003C19.943 17.7003 20.3265 17.6151 20.6504 17.4446C20.9771 17.2741 21.2285 17.0327 21.4046 16.7202C21.5808 16.4048 21.6688 16.0355 21.6688 15.6122L22.0268 15.6676H19.6575V14.4318H23.1987V15.4801C23.1987 16.2273 23.0396 16.8736 22.7214 17.419C22.4032 17.9645 21.9657 18.3849 21.4089 18.6804C20.8521 18.973 20.2129 19.1193 19.4913 19.1193C18.6873 19.1193 17.9813 18.9389 17.3734 18.5781C16.7683 18.2145 16.2952 17.6989 15.9543 17.0312C15.6163 16.3608 15.4472 15.5653 15.4472 14.6449C15.4472 13.9403 15.5467 13.3111 15.7455 12.7571C15.9472 12.2031 16.2285 11.733 16.5893 11.3466C16.9501 10.9574 17.3734 10.6619 17.8592 10.4602C18.345 10.2557 18.8734 10.1534 19.4444 10.1534C19.9273 10.1534 20.3776 10.2244 20.7952 10.3665C21.2129 10.5057 21.5836 10.7045 21.9075 10.9631C22.2342 11.2216 22.5026 11.5284 22.7129 11.8835C22.9231 12.2386 23.0609 12.6307 23.1262 13.0597H21.5154Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                    <div className="">
                      <div className="text-[[14] text-white">
                        PARENTAL GUIDENCE
                      </div>
                      <div className="text-white text-[12px]">
                        Some material may not be suitable for children. Parental
                        guidance advised.
                      </div>
                    </div>
                  </div>
                )}

                {item.age === "g" && (
                  <div className="flex items-center gap-2">
                    <div className="">
                      <svg
                        width="30"
                        height="30"
                        viewBox="0 0 30 30"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <circle
                          cx="15"
                          cy="15"
                          r="14"
                          fill="#58A942"
                          stroke="white"
                          stroke-width="2"
                        />
                        <path
                          d="M17.1781 13.0597C17.1071 12.8295 17.0091 12.6236 16.8841 12.4418C16.7619 12.2571 16.6142 12.0994 16.4409 11.9688C16.2704 11.8381 16.0744 11.7401 15.8528 11.6747C15.6312 11.6065 15.3897 11.5724 15.1284 11.5724C14.6596 11.5724 14.242 11.6903 13.8755 11.9261C13.5091 12.1619 13.2207 12.5085 13.0105 12.9659C12.8031 13.4205 12.6994 13.9744 12.6994 14.6278C12.6994 15.2869 12.8031 15.8452 13.0105 16.3026C13.2179 16.7599 13.5062 17.108 13.8755 17.3466C14.2449 17.5824 14.6738 17.7003 15.1625 17.7003C15.6056 17.7003 15.9892 17.6151 16.313 17.4446C16.6397 17.2741 16.8912 17.0327 17.0673 16.7202C17.2434 16.4048 17.3315 16.0355 17.3315 15.6122L17.6895 15.6676H15.3201V14.4318H18.8613V15.4801C18.8613 16.2273 18.7022 16.8736 18.3841 17.419C18.0659 17.9645 17.6284 18.3849 17.0716 18.6804C16.5147 18.973 15.8755 19.1193 15.1539 19.1193C14.35 19.1193 13.644 18.9389 13.036 18.5781C12.4309 18.2145 11.9579 17.6989 11.617 17.0312C11.2789 16.3608 11.1099 15.5653 11.1099 14.6449C11.1099 13.9403 11.2093 13.3111 11.4082 12.7571C11.6099 12.2031 11.8912 11.733 12.252 11.3466C12.6127 10.9574 13.036 10.6619 13.5218 10.4602C14.0076 10.2557 14.536 10.1534 15.1071 10.1534C15.59 10.1534 16.0403 10.2244 16.4579 10.3665C16.8755 10.5057 17.2463 10.7045 17.5701 10.9631C17.8968 11.2216 18.1653 11.5284 18.3755 11.8835C18.5858 12.2386 18.7235 12.6307 18.7889 13.0597H17.1781Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                    <div className="">
                      <div className="text-[[14] text-white">GENERAL</div>
                      <div className="text-white text-[12px]">
                        Suitable for all ages. No age restriction.
                        Family-friendly content.
                      </div>
                    </div>
                  </div>
                )}

                {item.age === "12A" && (
                  <div className="flex items-center gap-2">
                    <div className="">
                      <svg
                        width="30"
                        height="30"
                        viewBox="0 0 30 30"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <circle
                          cx="15"
                          cy="15"
                          r="14"
                          fill="#FDB220"
                          stroke="white"
                          stroke-width="2"
                        />
                        <path
                          d="M8.42211 10.2727V19H6.84115V11.8111H6.79001L4.74882 13.1151V11.6662L6.91785 10.2727H8.42211ZM10.59 19V17.858L13.6199 14.8878C13.9096 14.5952 14.1511 14.3352 14.3443 14.108C14.5375 13.8807 14.6824 13.6605 14.7789 13.4474C14.8755 13.2344 14.9238 13.0071 14.9238 12.7656C14.9238 12.4901 14.8613 12.2543 14.7363 12.0582C14.6113 11.8594 14.4395 11.706 14.2207 11.598C14.002 11.4901 13.7534 11.4361 13.475 11.4361C13.188 11.4361 12.9366 11.4957 12.7207 11.6151C12.5048 11.7315 12.3372 11.8977 12.2179 12.1136C12.1014 12.3295 12.0431 12.5866 12.0431 12.8849H10.5389C10.5389 12.331 10.6653 11.8494 10.9181 11.4403C11.171 11.0312 11.519 10.7145 11.9622 10.4901C12.4082 10.2656 12.9196 10.1534 13.4963 10.1534C14.0815 10.1534 14.5957 10.2628 15.0389 10.4815C15.4821 10.7003 15.8258 11 16.0701 11.3807C16.3173 11.7614 16.4409 12.196 16.4409 12.6847C16.4409 13.0114 16.3784 13.3324 16.2534 13.6477C16.1284 13.9631 15.9082 14.3125 15.5929 14.696C15.2804 15.0795 14.8414 15.544 14.2761 16.0895L12.7718 17.6193V17.679H16.573V19H10.59ZM19.2011 19H17.5136L20.5861 10.2727H22.5378L25.6145 19H23.927L21.596 12.0625H21.5278L19.2011 19ZM19.2565 15.5781H23.8588V16.848H19.2565V15.5781Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                    <div className="">
                      <div className="text-[[14] text-white">
                        12 AND ACCOMPANIED
                      </div>
                      <div className="text-white text-[12px]">
                        Not suitable for under 12s without adult supervision.
                        Moderate content.
                      </div>
                    </div>
                  </div>
                )}

                {item.age === "15A" && (
                  <div className="flex items-center gap-2">
                    <div className="">
                      <svg
                        width="30"
                        height="30"
                        viewBox="0 0 30 30"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <circle
                          cx="15"
                          cy="15"
                          r="14"
                          fill="#FD2020"
                          stroke="white"
                          stroke-width="2"
                        />
                        <path
                          d="M8.3518 10.2727V19H6.77083V11.8111H6.7197L4.6785 13.1151V11.6662L6.84754 10.2727H8.3518ZM13.5538 19.1193C12.9856 19.1193 12.4771 19.0128 12.0282 18.7997C11.5794 18.5838 11.2228 18.2884 10.9586 17.9134C10.6973 17.5384 10.5581 17.1094 10.541 16.6264H12.0751C12.1035 16.9844 12.2583 17.277 12.5396 17.5043C12.8208 17.7287 13.1589 17.8409 13.5538 17.8409C13.8635 17.8409 14.139 17.7699 14.3805 17.6278C14.622 17.4858 14.8123 17.2884 14.9515 17.0355C15.0907 16.7827 15.1589 16.4943 15.1561 16.1705C15.1589 15.8409 15.0893 15.5483 14.9473 15.2926C14.8052 15.0369 14.6106 14.8366 14.3635 14.6918C14.1163 14.544 13.8322 14.4702 13.5112 14.4702C13.2498 14.4673 12.9927 14.5156 12.7399 14.6151C12.487 14.7145 12.2868 14.8452 12.139 15.0071L10.7115 14.7727L11.1674 10.2727H16.2299V11.5938H12.4757L12.2243 13.9077H12.2754C12.4373 13.7173 12.666 13.5597 12.9615 13.4347C13.2569 13.3068 13.5808 13.2429 13.9331 13.2429C14.4615 13.2429 14.9331 13.3679 15.3478 13.6179C15.7626 13.8651 16.0893 14.206 16.3279 14.6406C16.5666 15.0753 16.6859 15.5724 16.6859 16.1321C16.6859 16.7088 16.5524 17.223 16.2853 17.6747C16.0211 18.1236 15.6532 18.4773 15.1816 18.7358C14.7129 18.9915 14.1703 19.1193 13.5538 19.1193ZM19.2714 19H17.5839L20.6564 10.2727H22.6081L25.6848 19H23.9973L21.6663 12.0625H21.5981L19.2714 19ZM19.3268 15.5781H23.9291V16.848H19.3268V15.5781Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                    <div className="">
                      <div className="text-[[14] text-white">
                        15 AND ACCOMPANIED
                      </div>
                      <div className="text-white text-[12px]">
                        Not suitable for under 15s without adult supervision.
                        Strong content.
                      </div>
                    </div>
                  </div>
                )}

                {item.age === "16" && (
                  <div className="flex items-center gap-2">
                    <div className="">
                      <svg
                        width="30"
                        height="30"
                        viewBox="0 0 30 30"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <circle
                          cx="15"
                          cy="15"
                          r="14"
                          fill="#6C1AD7"
                          stroke="white"
                          stroke-width="2"
                        />
                        <path
                          d="M12.5758 10.2727V19H10.9949V11.8111H10.9437L8.90255 13.1151V11.6662L11.0716 10.2727H12.5758ZM17.9398 19.1193C17.5222 19.1165 17.1145 19.044 16.7168 18.902C16.319 18.7571 15.9611 18.5227 15.6429 18.1989C15.3247 17.8722 15.0719 17.4389 14.8844 16.8991C14.6969 16.3565 14.6046 15.6847 14.6074 14.8835C14.6074 14.1364 14.6869 13.4702 14.846 12.8849C15.0051 12.2997 15.2338 11.8054 15.5321 11.402C15.8304 10.9957 16.1898 10.6861 16.6102 10.473C17.0335 10.2599 17.5065 10.1534 18.0293 10.1534C18.5776 10.1534 19.0634 10.2614 19.4867 10.4773C19.9128 10.6932 20.2565 10.9886 20.5179 11.3636C20.7793 11.7358 20.9412 12.1562 21.0037 12.625H19.4483C19.3688 12.2898 19.2054 12.0227 18.9582 11.8239C18.7139 11.6222 18.4043 11.5213 18.0293 11.5213C17.4242 11.5213 16.9582 11.7841 16.6315 12.3097C16.3077 12.8352 16.1443 13.5568 16.1415 14.4744H16.2011C16.3403 14.2244 16.5207 14.0099 16.7423 13.831C16.9639 13.652 17.2139 13.5142 17.4923 13.4176C17.7736 13.3182 18.0705 13.2685 18.383 13.2685C18.8943 13.2685 19.3531 13.3906 19.7594 13.6349C20.1685 13.8793 20.4923 14.2159 20.731 14.6449C20.9696 15.071 21.0875 15.5597 21.0847 16.1108C21.0875 16.6847 20.9568 17.2003 20.6926 17.6577C20.4284 18.1122 20.0605 18.4702 19.5889 18.7315C19.1173 18.9929 18.5676 19.1222 17.9398 19.1193ZM17.9313 17.8409C18.2409 17.8409 18.5179 17.7656 18.7622 17.6151C19.0065 17.4645 19.1997 17.2614 19.3418 17.0057C19.4838 16.75 19.5534 16.4631 19.5506 16.1449C19.5534 15.8324 19.4852 15.5497 19.346 15.2969C19.2097 15.044 19.0207 14.8437 18.7793 14.696C18.5378 14.5483 18.2622 14.4744 17.9526 14.4744C17.7224 14.4744 17.508 14.5185 17.3091 14.6065C17.1102 14.6946 16.9369 14.8168 16.7892 14.973C16.6415 15.1264 16.525 15.3054 16.4398 15.5099C16.3574 15.7116 16.3148 15.9276 16.3119 16.1577C16.3148 16.4616 16.3858 16.7415 16.525 16.9972C16.6642 17.2528 16.856 17.4574 17.1003 17.6108C17.3446 17.7642 17.6216 17.8409 17.9313 17.8409Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                    <div className="">
                      <div className="text-[[14] text-white">16 AND OVER</div>
                      <div className="text-white text-[12px]">
                        Suitable for 16 and over. Intense content.
                      </div>
                    </div>
                  </div>
                )}

                {item.age === "18" && (
                  <div className="flex items-center gap-2">
                    <div className="">
                      <svg
                        width="30"
                        height="30"
                        viewBox="0 0 30 30"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <circle
                          cx="15"
                          cy="15"
                          r="14"
                          fill="#222122"
                          stroke="white"
                          stroke-width="2"
                        />
                        <path
                          d="M12.5934 10.2727V19H11.0125V11.8111H10.9613L8.92013 13.1151V11.6662L11.0892 10.2727H12.5934ZM17.8636 19.1193C17.2301 19.1193 16.6676 19.0128 16.1761 18.7997C15.6875 18.5866 15.3039 18.2955 15.0255 17.9261C14.75 17.554 14.6136 17.1321 14.6164 16.6605C14.6136 16.294 14.6932 15.9574 14.8551 15.6506C15.017 15.3438 15.2358 15.0881 15.5113 14.8835C15.7897 14.6761 16.0994 14.544 16.4403 14.4872V14.4276C15.9914 14.3281 15.6278 14.0994 15.3494 13.7415C15.0738 13.3807 14.9375 12.9645 14.9403 12.4929C14.9375 12.044 15.0625 11.6435 15.3153 11.2912C15.5682 10.9389 15.9147 10.6619 16.3551 10.4602C16.7954 10.2557 17.2983 10.1534 17.8636 10.1534C18.4233 10.1534 18.9218 10.2557 19.3593 10.4602C19.7997 10.6619 20.1463 10.9389 20.3991 11.2912C20.6548 11.6435 20.7826 12.044 20.7826 12.4929C20.7826 12.9645 20.642 13.3807 20.3608 13.7415C20.0824 14.0994 19.723 14.3281 19.2826 14.4276V14.4872C19.6236 14.544 19.9304 14.6761 20.2031 14.8835C20.4787 15.0881 20.6974 15.3438 20.8593 15.6506C21.0241 15.9574 21.1065 16.294 21.1065 16.6605C21.1065 17.1321 20.9673 17.554 20.6889 17.9261C20.4105 18.2955 20.027 18.5866 19.5383 18.7997C19.0525 19.0128 18.4943 19.1193 17.8636 19.1193ZM17.8636 17.9006C18.1903 17.9006 18.4744 17.8452 18.7159 17.7344C18.9574 17.6207 19.1449 17.4616 19.2784 17.2571C19.4119 17.0526 19.4801 16.8168 19.4829 16.5497C19.4801 16.2713 19.4076 16.0256 19.2656 15.8125C19.1264 15.5966 18.9346 15.4276 18.6903 15.3054C18.4488 15.1832 18.1733 15.1222 17.8636 15.1222C17.5511 15.1222 17.2727 15.1832 17.0284 15.3054C16.7841 15.4276 16.5909 15.5966 16.4488 15.8125C16.3096 16.0256 16.2414 16.2713 16.2443 16.5497C16.2414 16.8168 16.3068 17.0526 16.4403 17.2571C16.5738 17.4588 16.7613 17.6165 17.0028 17.7301C17.2471 17.8437 17.5341 17.9006 17.8636 17.9006ZM17.8636 13.9247C18.1307 13.9247 18.3664 13.8707 18.571 13.7628C18.7784 13.6548 18.9417 13.5043 19.0611 13.3111C19.1804 13.1179 19.2414 12.8949 19.2443 12.642C19.2414 12.392 19.1818 12.1733 19.0653 11.9858C18.9488 11.7955 18.7869 11.6491 18.5795 11.5469C18.3721 11.4418 18.1335 11.3892 17.8636 11.3892C17.588 11.3892 17.3451 11.4418 17.1349 11.5469C16.9275 11.6491 16.7656 11.7955 16.6491 11.9858C16.5355 12.1733 16.4801 12.392 16.4829 12.642C16.4801 12.8949 16.5369 13.1179 16.6534 13.3111C16.7727 13.5014 16.9361 13.652 17.1434 13.7628C17.3537 13.8707 17.5937 13.9247 17.8636 13.9247Z"
                          fill="white"
                        />
                      </svg>
                    </div>
                    <div className="">
                      <div className="text-[[14] text-white">18 AND OVER</div>
                      <div className="text-white text-[12px]">
                        Restricted to 18 and over. Graphic content.
                      </div>
                    </div>
                  </div>
                )}

                <h2 className="text-4xl font-extrabold text-white mt-2">
                  {item.title}
                </h2>
                <div className="mt-2 text-white text-xs w-[500px] max-w-[100%]">
                  {item.details}
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <div className="flex gap-1 items-center">
                    <img
                      src="/assets/images/imdb.png"
                      alt=""
                      className="w-[60px]"
                    />
                    <div className="text-white text-xs">{item.rating}/10</div>
                  </div>
                  <div className="flex items-center text-white gap-1">
                    <IoTimeSharp />
                    <div className=" text-xs"> {item.duration}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Slide;
