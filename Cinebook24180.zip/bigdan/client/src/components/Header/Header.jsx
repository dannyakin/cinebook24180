import React, { useState } from "react";
import Search from "../Search/Search";
import { Link } from "react-router-dom";
import AuthScreen from "../../pages/Auth/AuthScreen";
import { useSelector } from "react-redux";

const Header = () => {
  const [auth, setAuth] = useState(null);
   const currentUserString = localStorage.getItem("currentUser");
   const LocalUser = JSON.parse(currentUserString);
  return (
    <>
      <div className="w-full h-14 bg-white shadow z-40">
        <div className="container mx-auto flex items-center justify-between h-full w-full">
          {/* Title*/}
          <div className="text-2xl font-extrabold">
            Cine<span className="text-orange-600">Booker </span>
          </div>
          <div className="">
            {/* Search */}
            <Search />
          </div>
          <div className="flex items-center justify-center gap-5 text-sm text-gray-500">
            <div className="text-orange-500">
              <div> Home </div>
            </div>

            {LocalUser ? (
              <div className="">
                <Link to="/logout">Log Out</Link>
              </div>
            ) : (
              <div className="">
                <Link to="/join">Join Us </Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {auth && (
        <div className="z-0">
          {" "}
          <AuthScreen auth={auth} setAuth={setAuth} />{" "}
        </div>
      )}
    </>
  );
};

export default Header;
