import { RouterProvider, createBrowserRouter } from "react-router-dom";
import Welcome from "./pages/Welcome/Welcome";
import Layout from "./components/Layout/Layout";
import Admin from "./pages/Admin/Admin";
import Home from "./pages/Admin/Home";
import { useSelector, useDispatch } from "react-redux";
import { useEffect } from "react";
import { setToken, setUser } from "./function/Redux/auth/authSlice";
import User from "./pages/User/User";
import Private from "./function/Routes/Private";
import Movie from "./pages/Admin/Movie";
import Users from "./pages/Auth/users";
import Book from "./components/Movies/Book";
import Register from "./pages/Auth/Register";
import AuthScreen from "./pages/Auth/AuthScreen";
import Ticketes from "./pages/Admin/Ticketes";
import Public from "./function/Routes/Public";

function App() {
  const dispatch = useDispatch();
  const { currentUser, token } = useSelector((state) => state.auth);

  const currentUserString = localStorage.getItem("currentUser");
  const LocalUser = JSON.parse(currentUserString);
  console.log(LocalUser);
  const Localtoken = localStorage.getItem(token);
 useEffect(() => {
   if (Localtoken && LocalUser) {
     dispatch(setUser(LocalUser));
     dispatch(setToken(Localtoken));
   }
 }, [dispatch, Localtoken, LocalUser]);
  const routes = createBrowserRouter([
    {
      element: <Private />,
      children: [
        {
          element: <Layout />,
          children: [
            {
              path: "/",
              exact: true,
              element: <Welcome />,
            },
            {
              path: "/user",
              element: <User />,
            },
            {
              path: "/book/:movieId",
              element: <Book />,
            },
          ],
        },
        {
          element: <Admin />,
          children: [
            {
              path: "/admin",
              element: <Home />,
            },
            {
              path: "/movies",
              element: <Movie />,
            },
            {
              path: "/tickets",
              element: <Ticketes />,
            },
            {
              path: "/users",
              element: <Users />,
            },
          ],
        },
      ],
    },

    {
      element: <Public />,
      children: [
        {
          path: "/join",
          element: <AuthScreen />,
        },
      ],
    },
  ]);
  return (
    <>
      <RouterProvider router={routes} />
    </>
  );
}

export default App;
