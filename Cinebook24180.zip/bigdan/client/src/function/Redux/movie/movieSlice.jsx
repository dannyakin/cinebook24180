import { createSlice } from "@reduxjs/toolkit";
import {
  createMovieThunk,
  fetchMoviesThunk,
  getMovieByIdThunk,
  deleteMovieThunk,
} from "./movieAction";

const initialState = {
  loading: false,
  movies: [],
  error: null,
  movie: null,
};

const moviesSlice = createSlice({
  name: "movies",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    // Reducer for creating a movie
    builder.addCase(createMovieThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(createMovieThunk.fulfilled, (state, action) => {
      state.loading = false;
      state.movies.push(action.payload);
    });
    builder.addCase(createMovieThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload;
    });

    // Reducer for fetching all movies
    builder.addCase(fetchMoviesThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(fetchMoviesThunk.fulfilled, (state, action) => {
      state.loading = false;
      state.movies = action.payload;
    });
    builder.addCase(fetchMoviesThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload;
    });

    // Reducer for fetching a single movie by ID
    builder.addCase(getMovieByIdThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(getMovieByIdThunk.fulfilled, (state, action) => {
      state.loading = false;
      state.movie = action.payload;
      // Update the specific movie in the state or handle as needed
    });
    builder.addCase(getMovieByIdThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload;
    });

    // Reducer for deleting a movie by ID
    builder.addCase(deleteMovieThunk.pending, (state) => {
      state.loading = true;
      state.error = null;
    });
    builder.addCase(deleteMovieThunk.fulfilled, (state, action) => {
      state.loading = false;
      // Remove the deleted movie from the state or handle as needed
    });
    builder.addCase(deleteMovieThunk.rejected, (state, action) => {
      state.loading = false;
      state.error = action.payload;
    });
  },
});

export default moviesSlice.reducer;
