import { createAsyncThunk } from "@reduxjs/toolkit";
import { getDataAPI, postDataAPI, deleteDataAPI } from "../../../utils/api"; // Assuming you have utility functions for API requests

// Async thunk action creator for creating a movie
const createMovieThunk = createAsyncThunk(
  "movies/create",
  async (movieData, { rejectWithValue }) => {
    try {
      // Make API request to create the movie
      console.log(movieData);
      const response = await postDataAPI("api/movies", movieData);
      return response.data; // Return the newly created movie data
    } catch (error) {
      // Handle errors
      return rejectWithValue(error.response.data.message);
    }
  }
);

// Async thunk action creator for fetching all movies
const fetchMoviesThunk = createAsyncThunk(
  "movies/fetchAll",
  async (_, { rejectWithValue }) => {
    try {
      // Make API request to fetch all movies
      const response = await getDataAPI("api/movies");
      return response.data; // Return the array of movies
    } catch (error) {
      // Handle errors
      return rejectWithValue(error.response.data.message);
    }
  }
);

// Async thunk action creator for getting a single movie by ID
const getMovieByIdThunk = createAsyncThunk(
  "movies/getById",
  async (movieId, { rejectWithValue }) => {
    try {
      // Make API request to get movie by ID
      const response = await getDataAPI(`api/movies/${movieId}`);
      return response.data; // Return the movie data
    } catch (error) {
      // Handle errors
      return rejectWithValue(error.response.data.message);
    }
  }
);

// Async thunk action creator for deleting a movie by ID
const deleteMovieThunk = createAsyncThunk(
  "movies/delete",
  async (movieId, { rejectWithValue }) => {
    try {
      // Make API request to delete movie by ID
      const response = await deleteDataAPI(`api/movies/${movieId}`);
      return response.data; // Return the success message
    } catch (error) {
      // Handle errors
      return rejectWithValue(error.response.data.message);
    }
  }
);

export {
  createMovieThunk,
  fetchMoviesThunk,
  getMovieByIdThunk,
  deleteMovieThunk,
};
