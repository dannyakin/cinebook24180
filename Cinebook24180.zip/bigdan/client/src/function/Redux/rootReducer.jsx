import { combineReducers } from "@reduxjs/toolkit";
import authReducer from "./auth/authSlice";
import novieReducer from "./movie/movieSlice";
import ticketReducer from "./ticket/ticketSlice";
// Import other reducers as needed

const rootReducer = combineReducers({
  auth: authReducer,
  movies: novieReducer,
  ticket: ticketReducer,
  // Add other reducers here
});

export default rootReducer;
