// ticketSlice.js

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { getDataAPI, postDataAPI } from "../../../utils/api";

// Define the initial state
const initialState = {
  tickets: [],
  ticket: null,
  loading: false,
  error: null,
};

// Define the thunk for fetching all tickets
export const fetchTickets = createAsyncThunk(
  "tickets/fetchTickets",
  async () => {
    const token = await localStorage.getItem('token');
    try {
      const response = await getDataAPI("api/tickets", token); // Adjust the API endpoint as per your backend route
      return response.data;
    } catch (error) {
      throw Error("Failed to fetch tickets");
    }
  }
);

// Define the thunk for fetching a ticket by ID
export const fetchTicketById = createAsyncThunk(
  "tickets/fetchTicketById",
  async (ticketId) => {
    const token = await localStorage.getItem('token');
    try {
      const response = await getDataAPI(`api/tickets/${ticketId}`, token); // Adjust the API endpoint as per your backend route

      return response.data;
    } catch (error) {
      throw Error("Failed to fetch ticket by ID");
    }
  }
);

// Define the thunk for creating a ticket
export const createTicket = createAsyncThunk(
  "tickets/createTicket",
  async (ticketData) => {
    const token = await localStorage.getItem('token');
    console.log(token)
    try {
      const response = await postDataAPI("api/tickets", ticketData, token); // Adjust the API endpoint as per your backend route
      return response.data;
    } catch (error) {
      console.log(error);
      throw Error("Failed to create ticket");
    }
  }
);

// Create the ticket slice
const ticketSlice = createSlice({
  name: "tickets",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Fetch all tickets reducers
      .addCase(fetchTickets.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTickets.fulfilled, (state, action) => {
        state.loading = false;
        state.tickets = action.payload;
      })
      .addCase(fetchTickets.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Fetch ticket by ID reducers
      .addCase(fetchTicketById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTicketById.fulfilled, (state, action) => {
        state.loading = false;
        state.ticket = action.payload;
      })
      .addCase(fetchTicketById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      })
      // Create ticket reducers
      .addCase(createTicket.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createTicket.fulfilled, (state, action) => {
        state.loading = false;
        state.ticket = action.payload; // Assuming the new ticket is added to the tickets array
      })
      .addCase(createTicket.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

// Export actions and reducer
export const {} = ticketSlice.actions;
export default ticketSlice.reducer;
