import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  loading: false,
  currentUser: null,
  token: null,
  isAuthenticated: null,
  isAdmin: false,
  error: null,
  users: [],
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setUser: (state, action) => {
      state.currentUser = action.payload;
      state.isAuthenticated = true;
    },
    setToken: (state, action) => {
      state.token = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    clearUser: (state) => {
      state.loading = false;
      state.currentUser = null;
      state.token = null;
      state.isAuthenticated = false;
      state.isAdmin = false;
    },
    setAdminStatus: (state, action) => {
      state.isAdmin = action.payload;
    },
    setError: (state, action) => {
      state.error = action.payload;
    },

    setAllUser: (state, action) => {
      state.users = action.payload;
    },
  },
});

export const {
  setUser,
  setToken,
  setLoading,
  clearUser,
  setAdminStatus,
  setError,
  setAllUser,
} = authSlice.actions;

export default authSlice.reducer;
