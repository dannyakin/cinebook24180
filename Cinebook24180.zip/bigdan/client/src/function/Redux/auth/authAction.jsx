import { createAsyncThunk } from "@reduxjs/toolkit";
import {
  setAllUser,
  setError,
  setLoading,
  setToken,
  setUser,
} from "./authSlice";
import { postDataAPI, getDataAPI } from "../../../utils/api";

// Thunk to handle user registration
const registerThunk = createAsyncThunk(
  "auth/register",
  async (userData, { dispatch }) => {
    try {
      dispatch(setError(null));
      dispatch(setLoading(true));

      // Make API call to register user
      const res = await postDataAPI("api/register", userData);
      const { user, token } = res.data;

      // Set user data and token in Redux store and local storage
      dispatch(setUser(user));
      dispatch(setToken(token));
      localStorage.setItem("currentUser", JSON.stringify(user));
      localStorage.setItem("token", token);

      // Redirect based on user type
      if (user.userType === "admin") {
        window.location.href = "/admin";
      } else {
        window.location.href = "/user";
      }
    } catch (err) {
      dispatch(setError(err.response.data.message));
    } finally {
      dispatch(setLoading(false));
    }
  }
);

// Thunk to handle user login
const loginThunk = createAsyncThunk(
  "auth/login",
  async (userData, { dispatch }) => {
    try {
      dispatch(setError(null));
      dispatch(setLoading(true));

      // Make API call to authenticate user
      const res = await postDataAPI("api/login", userData);
      const { user, token } = res.data;

      // Set user data and token in Redux store and local storage
      dispatch(setUser(user));
      dispatch(setToken(token));
      localStorage.setItem("currentUser", JSON.stringify(user));
      localStorage.setItem("token", token);

      // Redirect based on user type
      if (user.userType === "admin") {
        window.location.href = "/admin";
      } else {
        window.location.href = "/user";
      }
    } catch (err) {
      dispatch(setError(err.response.data.message));
    } finally {
      dispatch(setLoading(false));
    }
  }
);

// Thunk to fetch all users
const fetchAllUsersThunk = createAsyncThunk(
  "auth/fetchAllUsers",
  async (_, { dispatch }) => {
    try {
      dispatch(setLoading(true));
      // Make API call to fetch all users
      const res = await getDataAPI("api/users");
      // Assuming res.data contains an array of user objects
      dispatch(setAllUser(res.data));
    } catch (err) {
      // Handle errors
      dispatch(setError(err.response.data.message));
    } finally {
      dispatch(setLoading(false));
    }
  }
);

export { registerThunk, loginThunk, fetchAllUsersThunk };
