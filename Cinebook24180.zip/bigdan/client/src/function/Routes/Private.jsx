import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Outlet } from "react-router-dom";
import AuthScreen from "../../pages/Auth/AuthScreen";

const Private = () => {
  const { currentUser, token } = useSelector((state) => state.auth);
  const [isAuth, setIsAuth] = useState(null);
  useEffect(() => {
    if (token) {
      setIsAuth(true);
    } else {
      setIsAuth(false);
    }
  }, []);

  if (isAuth === null) return "Loading.....";
  return <div>{isAuth === false ? <Outlet /> : <AuthScreen />}</div>;
};

export default Private;