import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Outlet } from "react-router-dom";
import Welcome from "../../pages/Welcome/Welcome";

const Public = () => {
  const { currentUser, token } = useSelector((state) => state.auth);
  const [isAuth, setIsAuth] = useState(null);
  useEffect(() => {
    if (token) {
      setIsAuth(true);
    } else {
      setIsAuth(false);
    }
  }, []);

  if (isAuth === null) return "Loading.....";
  return <div>{isAuth === true ? <Outlet /> : <Welcome />}</div>;
};

export default Public;
