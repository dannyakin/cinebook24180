import React, { useState } from "react";
import Login from "./Login";
import Register from "./Register";

const AuthScreen = () => {
    const [auth, setAuth] = useState(1);
  return (
    <div className="fixed top-0 left-0 w-screen h-screen backdrop:blur-[50] bg-white flex items-center justify-center p-3 z-0">
      {auth && auth === 2 && <Login setAuth={setAuth} />}
      {auth && auth === 1 && <Register setAuth={setAuth} />}
    </div>
  );
};

export default AuthScreen;
