import React from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useDispatch, useSelector } from "react-redux";
import { registerThunk } from "../../function/Redux/auth/authAction";
import { Link } from "react-router-dom";


const Register = ({ setAuth }) => {
  const { error, loading } = useSelector((state) => state.auth);
  const dispatch = useDispatch();
  return (
    <div className="min-w-[400px] shadow max-w-full min-h-[400px] max-h-full relative bg-white p-4 px-8 rounded-xl">
      <Link to="/"
        className="absolute cursor-pointer right-4 top-4"
        
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M6.4 19L5 17.6L10.6 12L5 6.4L6.4 5L12 10.6L17.6 5L19 6.4L13.4 12L19 17.6L17.6 19L12 13.4L6.4 19Z"
            fill="black"
          />
        </svg>
      </Link>

      {/* Registration form */}
      <div className="mb-4 mt-5">
        <div className="text-2xl text-orange-500">Join Now</div>
        <div className="text-sm text-gray-500">
          Fill your information to create a new account with us.
        </div>
      </div>
      <Formik
        initialValues={{
          fullName: "",
          email: "",
          password: "",
          confirmPassword: "",
        }}
        validationSchema={Yup.object({
          fullName: Yup.string().required("Full Name is required"),
          email: Yup.string()
            .email("Invalid email address")
            .required("Email is required"),
          password: Yup.string()
            .min(6, "Password must be at least 6 characters")
            .required("Password is required"),
          confirmPassword: Yup.string()
            .oneOf([Yup.ref("password"), null], "Passwords must match")
            .required("Confirm Password is required"),
        })}
        onSubmit={(userData) => {
          // Handle form submission here
          dispatch(registerThunk(userData));
        }}
      >
        <Form>
          <div>
            <Field
              className="border px-2 py-3 w-full rounded mb-2 text-xs"
              type="text"
              id="fullName"
              name="fullName"
              placeholder="Full Name"
            />
            <ErrorMessage
              name="fullName"
              component="small"
              className="text-red-500 text-xs mb-3"
            />
          </div>

          <div>
            <Field
              className="border px-2 py-3 w-full rounded mb-2 text-xs"
              type="email"
              id="email"
              name="email"
              placeholder="Email"
            />
            <ErrorMessage
              name="email"
              component="small"
              className="text-red-500 text-xs mb-3"
            />
          </div>

          <div>
            <Field
              className="border px-2 py-3 w-full rounded mb-2 text-xs"
              type="password"
              id="password"
              name="password"
              placeholder="password"
            />
            <ErrorMessage
              name="password"
              component="small"
              className="text-red-500 text-xs mb-3"
            />
          </div>

          <div>
            <Field
              className="border px-2 py-3 w-full rounded mb-2 text-xs"
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              placeholder="Confirm Password"
            />
            <ErrorMessage
              name="confirmPassword"
              component="small"
              className="text-red-500 text-xs mb-3"
            />
          </div>
          <div className="text-xs text-gray-500">
            By creating an account you agree to out terms and conditions
          </div>

          <button
            type="submit"
            disabled={loading}
            className="bg-orange-600 w-full p-2 text-white mt-4 mb-4 rounded"
          >
            {loading ? "Loading..." : "Register"}
          </button>
        </Form>
      </Formik>
      {error && (
        <div className="text-red-500 text-xs mb-3 text-center">{error}</div>
      )}

      <div
        className=" cursor-pointer text-gray-600 text-xs text-center mb-5"
        onClick={() => {
          setAuth(2);
        }}
      >
        Already have an account ?
      </div>
      {/* End of registration form */}
    </div>
  );
};

export default Register;
