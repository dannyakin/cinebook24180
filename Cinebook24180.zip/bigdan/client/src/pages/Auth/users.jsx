import React, { useState, useEffect } from "react";
import { Table, Spin } from "antd";
import { fetchAllUsersThunk } from "../../function/Redux/auth/authAction";
import { useDispatch, useSelector } from "react-redux";

const Users = () => {
  const [loading, setLoading] = useState(true); // Add loading state
  const dispatch = useDispatch();

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true); // Set loading state to true before fetching
        await dispatch(fetchAllUsersThunk());
        setLoading(false); // Set loading state to false after fetching
      } catch (error) {
        console.error("Error fetching users:", error);
        setLoading(false); // Set loading state to false in case of error
      }
    };

    fetchData();
  }, [dispatch]);

  const { users } = useSelector((state) => state.auth);

  const columns = [
    {
      title: "Full Name",
      dataIndex: "fullName",
      key: "fullName",
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
    },
  ];

  return (
    <div>
      {loading ? ( // Render spinner if loading is true
        <Spin size="large" />
      ) : (
        <Table dataSource={users} columns={columns} />
      )}
    </div>
  );
};

export default Users;
