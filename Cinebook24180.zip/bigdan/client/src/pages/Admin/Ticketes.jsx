import React from 'react'

const Ticketes = () => {
  return (
    <div>Ticketes</div>
  )
}

export default Ticketes