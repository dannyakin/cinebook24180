import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate, Link, Outlet } from "react-router-dom";

const Admin = () => {
  const navigate = useNavigate();
  const { currentUser } = useSelector((state) => state.auth);

  useEffect(() => {
    if (currentUser && currentUser.userType !== "admin") {
      navigate("/");
    }
  }, [currentUser, navigate]); // Added navigate to the dependency array

  return (
    <>
      <div className="w-screen h-14 bg-white shadow">
        <div className="container mx-auto flex items-center justify-between h-full w-full">
          {/* Title*/}
          <div className="text-2xl font-extrabold">
            Cine<span className="text-orange-600">Booker Admin </span>
          </div>

          <div className="flex items-center justify-center gap-5 text-sm text-gray-500">
            <div className="text-orange-500">
              <div> Home </div>
            </div>
            <div className="">
              <Link to="/movies">Movies </Link>
            </div>
            <div className="">
              <Link to="/users">Users </Link>
            </div>
            <div className="">
              <Link to="/tickets">Tickets </Link>
            </div>
          </div>
        </div>
      </div>
      <div className="container mx-auto mt-4">
        <Outlet />
      </div>
    </>
  );
};

export default Admin;
