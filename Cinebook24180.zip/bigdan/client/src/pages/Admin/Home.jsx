import React from "react";
import DashboardCard from "../../components/Auth/DashboardCard";

const Home = () => {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
      <div className="w-full">
        <DashboardCard
          count="10"
          title="Users"
          details="Total Users of the application"
          icon="user"
          color="bg-purple-600"
          bgcolor="bg-purple-100"
        />
      </div>
      <div className="w-full">
        <DashboardCard
          count="10"
          title="Movie"
          details="Total Users of the application"
          icon="movie"
          color="bg-blue-600"
          bgcolor="bg-blue-100"
        />
      </div>
      <div className="w-full">
        <DashboardCard
          count="10"
          title="Ticket"
          details="Total Users of the application"
          icon="ticket"
          color="bg-red-600"
          bgcolor="bg-red-100"
        />
      </div>
      <div className="w-full">
        <DashboardCard
          count="10"
          title="Seat"
          details="Total Users of the application"
          icon="seat"
          color="bg-green-600"
          bgcolor="bg-green-100"
        />
      </div>
    </div>
  );
};

export default Home;
