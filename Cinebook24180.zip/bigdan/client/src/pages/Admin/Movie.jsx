import React, { useState } from "react";
import CreateMoview from "../../components/Auth/CreateMoview";
import MovieList from "../../components/Auth/MovieList";

const Movie = () => {
  const [create, setCreate] = useState(false);
  return (
    <div className="">
      <button
        className="bg-orange-600 p-4 text-white rounded"
        onClick={() => setCreate(true)}
      >
        Create Movies
      </button>

      <div className=" z-40">
        <MovieList />
      </div>
      {create && (
        <div className="absolute w-screen h-screen top-0 left-0 bg-opacity-90 bg-gray-900 backdrop-blur-3xl flex z-0 items-center justify-center">
          <CreateMoview setCreate={setCreate} />
        </div>
      )}
    </div>
  );
};

export default Movie;
