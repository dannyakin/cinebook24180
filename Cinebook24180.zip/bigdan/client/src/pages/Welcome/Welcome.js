import React from "react";
import Slide from "../../components/Slide/Slide";
import Movies from "../../components/Movies/Movies";

const Welcome = () => {
  return (
    <div className="">
      <Slide />
      <Movies />
    </div>
  );
};

export default Welcome;
